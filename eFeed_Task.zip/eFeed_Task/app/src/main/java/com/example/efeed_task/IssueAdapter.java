package com.example.efeed_task;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.squareup.picasso.Picasso;

import java.util.List;

public class IssueAdapter extends RecyclerView.Adapter<IssueAdapter.ViewHolder> {
    private List<Issue> issues;

    public IssueAdapter(List<Issue> issues) {
        this.issues = issues;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_issue, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        Issue issue = issues.get(position);

        holder.title.setText(issue.getTitle());
        holder.createdDate.setText("Created: " + issue.getCreatedDate());
        holder.closedDate.setText("Closed: " + (issue.getClosedDate() != null ? issue.getClosedDate() : "Not closed"));
        holder.userName.setText("User: " + issue.getUserName());

        Picasso.get().load(issue.getUserImage()).into(holder.userImage);
    }

    @Override
    public int getItemCount() {
        return issues.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView title;
        TextView createdDate;
        TextView closedDate;
        TextView userName;
        ImageView userImage;

        public ViewHolder(View itemView) {
            super(itemView);
            title = itemView.findViewById(R.id.titleTextView);
            createdDate = itemView.findViewById(R.id.createdDateTextView);
            closedDate = itemView.findViewById(R.id.closedDateTextView);
            userName = itemView.findViewById(R.id.userNameTextView);
            userImage = itemView.findViewById(R.id.userImageView);
        }
    }
}

