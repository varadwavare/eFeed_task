package com.example.efeed_task;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

import java.util.List;

public class MainActivity extends AppCompatActivity {
    private static final String BASE_URL = "https://api.github.com/repos/";

    private final String owner = "Varad";
    private final String repo = "Apps";

    private RecyclerView recyclerView;
    private IssueAdapter issueAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        issueAdapter = new IssueAdapter(List.of());
        recyclerView.setAdapter(issueAdapter);

        fetchData();
    }

    private void fetchData() {
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(BASE_URL + owner + "/" + repo + "/")
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        GitHubService service = retrofit.create(GitHubService.class);
        Call<List<Issue>> call = service.getClosedIssues(owner, repo);

        call.enqueue(new Callback<List<Issue>>() {
            @Override
            public void onResponse(Call<List<Issue>> call, Response<List<Issue>> response) {
                if (response.isSuccessful()) {
                    List<Issue> issues = response.body();
                    if (issues != null) {
                        issueAdapter = new IssueAdapter(issues);
                        recyclerView.setAdapter(issueAdapter);
                    }
                }
            }

            @Override
            public void onFailure(Call<List<Issue>> call, Throwable t) {
                // Handle network failure
            }
        });
    }
}
