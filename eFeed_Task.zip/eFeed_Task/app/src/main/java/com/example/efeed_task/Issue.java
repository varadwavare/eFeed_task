package com.example.efeed_task;

public class Issue {
    private String title;
    private String createdDate;
    private String closedDate;
    private String userName;
    private String userImage;

    // Constructors, getters, and setters

    public String getTitle() {
        return title;
    }

    public String getCreatedDate() {
        return createdDate;
    }

    public String getClosedDate() {
        return closedDate;
    }

    public String getUserName() {
        return userName;
    }

    public String getUserImage() {
        return userImage;
    }

    // Other methods if needed
}
